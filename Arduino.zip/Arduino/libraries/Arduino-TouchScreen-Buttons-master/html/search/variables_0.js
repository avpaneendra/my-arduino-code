var searchData=
[
  ['bordercolor',['borderColor',['../class_polygon.html#ac7e55927e6dda8a8ef0a9bf937564015',1,'Polygon']]]
];

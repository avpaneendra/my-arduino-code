var searchData=
[
  ['points',['points',['../class_polygon.html#a3f17a85c09bd04138f22ae31d18b6b4d',1,'Polygon']]]
];

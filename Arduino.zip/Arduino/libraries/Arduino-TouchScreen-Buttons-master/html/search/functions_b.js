var searchData=
[
  ['triangle',['Triangle',['../class_triangle.html#a477c11aa9dfce48a502e535874474fec',1,'Triangle']]]
];

var searchData=
[
  ['touchscreengeometry_2ecpp',['TouchScreenGeometry.cpp',['../_touch_screen_geometry_8cpp.html',1,'']]],
  ['touchscreengeometry_2eh',['TouchScreenGeometry.h',['../_touch_screen_geometry_8h.html',1,'']]],
  ['triangle',['Triangle',['../class_triangle.html',1,'Triangle'],['../class_triangle.html#a477c11aa9dfce48a502e535874474fec',1,'Triangle::Triangle()']]]
];

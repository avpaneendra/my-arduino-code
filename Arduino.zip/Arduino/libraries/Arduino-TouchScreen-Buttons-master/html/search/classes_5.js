var searchData=
[
  ['triangle',['Triangle',['../class_triangle.html',1,'']]]
];
